﻿using System.Windows.Controls;

namespace Automate
{
    public partial class AlertDialog : UserControl
    {
        public AlertDialog()
        {
            InitializeComponent();
        }
    }
}
