# TP2_14E_A24
# https://github.com/420-14E-FX-A24/ConceptionTP2AvecTests
!CI/CD Pipeline
# https://github.com/420-14E-FX-A24/ConceptionTP2AvecTests/actions/workflows/main.yml/badge.svg
# Automate
# integration continue 2
#
# Admin par défaut: "Frederic", mot de passe: "."
# \
# User par défaut: "Andre", mot de passe: "."
